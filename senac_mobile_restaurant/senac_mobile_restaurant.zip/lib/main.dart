import 'package:flutter/material.dart';
import 'splashscreen.dart';

void main() {
  runApp(const RestaurantApp());
}

// class RestaurantApp extends StatelessWidget {
//   const RestaurantApp({Key? key}) : super(key: key);

//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       // home: const MyHomePage(title: 'Flutter Demo Home Page'),
//     );
//   }
// }
